// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density14 = 1.225;
real comp_14 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet14;
int i;
real dmdt14;
real flow14[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC14, thread, position)
{
	
	face_t f;


	Thread *t;
	int n14 = N_TIME;
	real dt14;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet14 = 0;
	real flow_acce14; // = RP_Get_Real("dmdt14");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet14 += F_FLUX(f, thread);

		total_flow_mass_outlet14 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet14: %g\n", mass_flow_rate_outlet14);
//	printf("total mass downstream of outlet14: %g\n", total_flow_mass_outlet14);


	begin_f_loop(f, thread)
	{
		flow14[1] += F_FLUX(f, thread);
	}
	end_f_loop(f, thread)	

	dmdt14 = (flow14[1] - flow14[0])/dtime;

	Message("Derivative of mass flow rate14: %g\n", dmdt14);
	Message("flow14[1] value is: %g\n", flow14[1]);
	Message("flow14[0] value is: %g\n", flow14[0]);


	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet14/density14*13596009;// + 1628147*mass_flow_rate_outlet14/density14 + 13596*dmdt14/density14;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet14 = 0;
	flow14[0] = flow14[1];
	flow14[1] = 0;
}


