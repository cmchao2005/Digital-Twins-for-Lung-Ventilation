// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density11 = 1.225;
real comp_11 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet11;
int i;
real dmdt11;
real flow11[2] = {0.0, 0.0};


DEFINE_PROFILE(pressure_BC11, thread, position)
{
	
	face_t f;
	Thread *t;
	int n11 = N_TIME;
	real dt11;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet11 = 0;
	real flow_acce11; // = RP_Get_Real("dmdt11");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet11 += F_FLUX(f, thread);

		total_flow_mass_outlet11 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet11: %g\n", mass_flow_rate_outlet11);
//	printf("total mass downstream of outlet11: %g\n", total_flow_mass_outlet11);


	begin_f_loop(f, thread)
	{
		flow11[1] += F_FLUX(f, thread);	
	}
	end_f_loop(f, thread)	

	dmdt11 = (flow11[1] - flow11[0])/dtime;

	Message("Derivative of mass flow rate11: %g\n", dmdt11);
	Message("flow11[1] value is: %g\n", flow11[1]);
	Message("flow11[0] value is: %g\n", flow11[0]);
		


	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet11/density11*13596009;// + 1628147*mass_flow_rate_outlet11/density11 + 13596*dmdt11/density11;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet11 = 0;
	flow11[0] = flow11[1];
	flow11[1] = 0;
}


