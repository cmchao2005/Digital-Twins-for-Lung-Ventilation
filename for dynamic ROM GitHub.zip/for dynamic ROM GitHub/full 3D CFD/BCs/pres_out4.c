// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density4 = 1.225;
real comp_4 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet4;
real dmdt4;
int i;
real flow4[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC4, thread, position)
{
	
	face_t f;

	Thread *t;
	int n4 = N_TIME;
	real dt4;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet4 = 0;

	real flow_acce4; //= RP_Get_Real("dmdt4");

	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet4 += F_FLUX(f, thread);

		total_flow_mass_outlet4 += F_FLUX(f, thread)*dtime;
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet4: %g\n", mass_flow_rate_outlet4);
//	printf("total mass downstream of outlet4: %g\n", total_flow_mass_outlet4);


	begin_f_loop(f, thread)
	{
		flow4[1] += F_FLUX(f, thread);
	}
	end_f_loop(f, thread)	

	dmdt4 = (flow4[1] - flow4[0])/dtime;

	Message("Derivative of mass flow rate4: %g\n", dmdt4);
	Message("flow4[1] value is: %g\n", flow4[1]);
	Message("flow4[0] value is: %g\n", flow4[0]);
		


	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet4/density4*8624830;// + 1032839*mass_flow_rate_outlet4/density4 + 8625*dmdt4/density4;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet4 = 0;
	flow4[0] = flow4[1];
	flow4[1] = 0;
}


