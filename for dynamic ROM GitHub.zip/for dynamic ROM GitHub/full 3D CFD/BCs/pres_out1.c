// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density1 = 1.225;
real comp_1 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet1;
int i;
real dmdt1;
real flow1[2] = {0.0, 0.0};

DEFINE_PROFILE(pressure_BC1, thread, position)
{
	
	face_t f;

	Thread *t;
	int n1 = N_TIME;
	real dt1;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet1 = 0;

	real flow_acce1; // = dmdt1; //RP_Get_Real("dmdt1");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet1 += F_FLUX(f, thread);

		total_flow_mass_outlet1 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet1: %g\n", mass_flow_rate_outlet1);
//	printf("total mass downstream of outlet1: %g\n", total_flow_mass_outlet1);

	

	begin_f_loop(f, thread)
	{
		flow1[1] += F_FLUX(f, thread);
	}
	end_f_loop(f, thread)
	
	dmdt1 = (flow1[1] - flow1[0])/dtime;

//	Message("Derivative of mass flow rate1: %g\n", dmdt1);
//	Message("flow1[1] value is: %g\n", flow1[1]);
//	Message("flow1[0] value is: %g\n", flow1[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet1/density1*13343065;// + 1597836*mass_flow_rate_outlet1/density1;// + 13343*dmdt1/density1;

	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet1 = 0;
	flow1[0] = flow1[1];
	flow1[1] = 0;
}



