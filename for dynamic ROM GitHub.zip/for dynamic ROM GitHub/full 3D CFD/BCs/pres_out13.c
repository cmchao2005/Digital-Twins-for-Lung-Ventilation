// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density13 = 1.225;
real comp_13 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet13;
int i;
real dmdt13;
real flow13[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC13, thread, position)
{
	
	face_t f;

	Thread *t;
	int n13 = N_TIME;
	real dt13;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet13 = 0;
	real flow_acce13;// = RP_Get_Real("dmdt13");	

	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet13 += F_FLUX(f, thread);

		total_flow_mass_outlet13 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet13: %g\n", mass_flow_rate_outlet13);
//	printf("total mass downstream of outlet13: %g\n", total_flow_mass_outlet13);

	begin_f_loop(f, thread)
	{
		flow13[1] += F_FLUX(f, thread);
	}
	end_f_loop(f, thread)	

	dmdt13 = (flow13[1] - flow13[0])/dtime;

	Message("Derivative of mass flow rate13: %g\n", dmdt13);
	Message("flow13[1] value is: %g\n", flow13[1]);
	Message("flow13[0] value is: %g\n", flow13[0]);


	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet13/density13*13596009;// + 1628147*mass_flow_rate_outlet13/density13 + 13596*dmdt13/density13;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet13 = 0;
	flow13[0] = flow13[1];
	flow13[1] = 0;
}


