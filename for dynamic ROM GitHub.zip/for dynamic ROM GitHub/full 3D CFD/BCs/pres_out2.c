// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density2 = 1.225;
real comp_2 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet2;
real dmdt2;
int i;
real flow2[2] = {0.0, 0.0};


DEFINE_PROFILE(pressure_BC2, thread, position)
{
	
	face_t f;

	Thread *t;
	int n2 = N_TIME;
	real dt2;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet2 =0;

	real flow_acce2; // = RP_Get_Real("dmdt2");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet2 += F_FLUX(f, thread);

		total_flow_mass_outlet2 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet2: %g\n", mass_flow_rate_outlet2);
//	printf("total mass downstream of outlet2: %g\n", total_flow_mass_outlet2);


	begin_f_loop(f, thread)
	{
		flow2[1] += F_FLUX(f, thread);	
	}
	end_f_loop(f, thread)	

	dmdt2 = (flow2[1] - flow2[0])/dtime;

	Message("Derivative of mass flow rate2: %g\n", dmdt2);
	Message("flow2[1] value is: %g\n", flow2[1]);
	Message("flow2[0] value is: %g\n", flow2[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet2/density2*13343065;// + 1597836*mass_flow_rate_outlet2/density2 + 13343*dmdt2/density2;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet2 = 0;
	flow2[0] = flow2[1];
	flow2[1] = 0;
}


