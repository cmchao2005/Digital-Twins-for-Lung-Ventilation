// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density5 = 1.225;
real comp_5 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet5;
int i;
real dmdt5;
real flow5[2] = {0.0, 0.0};


DEFINE_PROFILE(pressure_BC5, thread, position)
{
	
	face_t f;
	Thread *t;
	int n5 = N_TIME;
	real dt5;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet5 = 0;

	real flow_acce5; //= RP_Get_Real("dmdt5");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet5 += F_FLUX(f, thread);

		total_flow_mass_outlet5 += F_FLUX(f, thread)*dtime;

	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet5: %g\n", mass_flow_rate_outlet5);
//	printf("total mass downstream of outlet5: %g\n", total_flow_mass_outlet5);

	begin_f_loop(f, thread)
	{
		flow5[1] += F_FLUX(f, thread);	
	}
	end_f_loop(f, thread)

	dmdt5 = (flow5[1] - flow5[0])/dtime;

	Message("Derivative of mass flow rate5: %g\n", dmdt5);
	Message("flow5[1] value is: %g\n", flow5[1]);
	Message("flow5[0] value is: %g\n", flow5[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet5/density5*9016422;// + 1079733*mass_flow_rate_outlet5/density5 + 9017*dmdt5/density5;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet5 = 0;
	flow5[0] = flow5[1];
	flow5[1] = 0;
}


