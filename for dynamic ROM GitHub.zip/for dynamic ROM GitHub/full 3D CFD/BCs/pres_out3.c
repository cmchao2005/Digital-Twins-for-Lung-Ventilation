// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density3 = 1.225;
real comp_3 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet3;
int i;
real dmdt3;
real flow3[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC3, thread, position)
{
	
	face_t f;

	Thread *t;
	int n3 = N_TIME;
	real dt3;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet3 = 0;

	real flow_acce3; // = RP_Get_Real("dmdt3");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet3 += F_FLUX(f, thread);

		total_flow_mass_outlet3 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet3: %g\n", mass_flow_rate_outlet3);
//	printf("total mass downstream of outlet3: %g\n", total_flow_mass_outlet3);


	begin_f_loop(f, thread)
	{
		flow3[1] += F_FLUX(f, thread);
	}
	end_f_loop(f, thread)		

	dmdt3 = (flow3[1] - flow3[0])/dtime;

	Message("Derivative of mass flow rate3: %g\n", dmdt3);
	Message("flow3[1] value is: %g\n", flow3[1]);
	Message("flow3[0] value is: %g\n", flow3[0]);
		
	
	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet3/density3*13343065;// + 1597836*mass_flow_rate_outlet3/density3 + 13343*dmdt3/density3;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet3 = 0;
	flow3[0] = flow3[1];
	flow3[1] = 0;
}

