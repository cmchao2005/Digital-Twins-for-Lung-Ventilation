// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density10 = 1.225;
real comp_10 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet10;
int i;
real dmdt10;
real flow10[2] = {0.0, 0.0};


DEFINE_PROFILE(pressure_BC10, thread, position)
{
	
	face_t f;

	Thread *t;
	int n10 = N_TIME;
	real dt10;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet10 = 0;
	real flow_acce10;// = RP_Get_Real("dmdt10");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet10 += F_FLUX(f, thread);

		total_flow_mass_outlet10 += F_FLUX(f, thread)*dtime;
	
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet10: %g\n", mass_flow_rate_outlet10);
//	printf("total mass downstream of outlet10: %g\n", total_flow_mass_outlet10);
	

	begin_f_loop(f, thread)
	{
		flow10[1]+= F_FLUX(f, thread);
	}
	end_f_loop(f, thread)

	dmdt10 = (flow10[1] - flow10[0])/dtime;

	Message("Derivative of mass flow rate10: %g\n", dmdt10);
	Message("flow10[1] value is: %g\n", flow10[1]);
	Message("flow10[0] value is: %g\n", flow10[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet10/density10*10302812;// + 1233781*mass_flow_rate_outlet10/density10 + 10303*dmdt10/density10;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet10 = 0;
	flow10[0] = flow10[1];
	flow10[1] = 0;
}


