// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density8 = 1.225;
real comp_8 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet8;
int i;
real dmdt8;
real flow8[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC8, thread, position)
{
	
	face_t f;

	Thread *t;
	int n8 = N_TIME;
	real dt8;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;

	real mass_flow_rate_outlet8 = 0;
	real flow_acce8;// = RP_Get_Real("dmdt8");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet8 += F_FLUX(f, thread);

		total_flow_mass_outlet8 += F_FLUX(f, thread)*dtime;
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet8: %g\n", mass_flow_rate_outlet8);
//	printf("total mass downstream of outlet8: %g\n", total_flow_mass_outlet8);


	begin_f_loop(f, thread)
	{
		flow8[1] += F_FLUX(f, thread);	
	}
	end_f_loop(f, thread)	

	dmdt8 = (flow8[1] - flow8[0])/dtime;

	Message("Derivative of mass flow rate8: %g\n", dmdt8);
	Message("flow8[1] value is: %g\n", flow8[1]);
	Message("flow8[0] value is: %g\n", flow8[0]);
		


	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet8/density8*10302812;// + 1233781*mass_flow_rate_outlet8/density8 + 10303*dmdt8/density8;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet8 = 0;
	flow8[0] = flow8[1];
	flow8[1] = 0;
}


