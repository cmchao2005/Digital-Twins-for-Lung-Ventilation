#include "udf.h"


DEFINE_PROFILE(unsteady_velocity, thread, position)
{
	face_t f;
	real t = CURRENT_TIME;
	real amp = 0.5;

	begin_f_loop(f, thread)
	{
		F_PROFILE(f, thread, position) = amp*sin(0.2*2*3.1415926*t);
	}
	end_f_loop(f, thread)
}