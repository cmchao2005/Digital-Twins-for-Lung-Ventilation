// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density12 = 1.225;
real comp_12 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet12;
int i;
real dmdt12;
real flow12[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC12, thread, position)
{
	
	face_t f;

	Thread *t;
	int n12 = N_TIME;
	real dt12;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet12 = 0;
	real flow_acce12; // = RP_Get_Real("dmdt12");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet12 += F_FLUX(f, thread);

		total_flow_mass_outlet12 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet12: %g\n", mass_flow_rate_outlet12);
//	printf("total mass downstream of outlet12: %g\n", total_flow_mass_outlet12);


	begin_f_loop(f, thread)
	{
		flow12[1] += F_FLUX(f, thread);
	}
	end_f_loop(f, thread)

	dmdt12 = (flow12[1] - flow12[0])/dtime;

	Message("Derivative of mass flow rate12: %g\n", dmdt12);
	Message("flow12[1] value is: %g\n", flow12[1]);
	Message("flow12[0] value is: %g\n", flow12[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet12/density12*13596009;// + 1628147*mass_flow_rate_outlet12/density12 + 13596*dmdt12/density12;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet12 = 0;
	flow12[0] = flow12[1];
	flow12[1] = 0;
}


