// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density9 = 1.225;
real comp_9 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet9;
int i;
real dmdt9;
real flow9[2] = {0.0, 0.0};


DEFINE_PROFILE(pressure_BC9, thread, position)
{
	
	face_t f;
	Thread *t;
	int n9 = N_TIME;
	real dt9;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet9 = 0;
	real flow_acce9;// = RP_Get_Real("dmdt9");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet9 += F_FLUX(f, thread);

		total_flow_mass_outlet9 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet9: %g\n", mass_flow_rate_outlet9);
//	printf("total mass downstream of outlet9: %g\n", total_flow_mass_outlet9);



	begin_f_loop(f, thread)
	{
		flow9[1] += F_FLUX(f, thread);		
	}
	end_f_loop(f, thread)

	dmdt9 = (flow9[1] - flow9[0])/dtime;

	Message("Derivative of mass flow rate9: %g\n", dmdt9);
	Message("flow9[1] value is: %g\n", flow9[1]);
	Message("flow9[0] value is: %g\n", flow9[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet9/density9*10302812;// + 1233781*mass_flow_rate_outlet9/density9 + 10303*dmdt9/density9;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet9 = 0;
	flow9[0] = flow9[1];
	flow9[1] = 0;
}


