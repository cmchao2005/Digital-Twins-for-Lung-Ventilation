// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density6 = 1.225;
real comp_6 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet6;
int i;
real dmdt6;
real flow6[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC6, thread, position)
{
	
	face_t f;

	Thread *t;
	int n6 = N_TIME;
	real dt6;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet6 = 0;
	real flow_acce6; // = RP_Get_Real("dmdt6");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet6 += F_FLUX(f, thread);

		total_flow_mass_outlet6 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet6: %g\n", mass_flow_rate_outlet6);
//	printf("total mass downstream of outlet6: %g\n", total_flow_mass_outlet6);

	begin_f_loop(f, thread)
	{
		flow6[1] += F_FLUX(f, thread);	
	}
	end_f_loop(f, thread)	

	dmdt6 = (flow6[1] - flow6[0])/dtime;

	Message("Derivative of mass flow rate6: %g\n", dmdt6);
	Message("flow6[1] value is: %g\n", flow6[1]);
	Message("flow6[0] value is: %g\n", flow6[0]);
		

	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet6/density6*9016422;// + 1079733*mass_flow_rate_outlet6/density6 + 9017*dmdt6/density6;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet6 = 0;
	flow6[0] = flow6[1];
	flow6[1] = 0;
}


