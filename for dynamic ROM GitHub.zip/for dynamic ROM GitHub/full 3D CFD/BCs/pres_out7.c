// UDF Dynamic pressure loading on outlet of lung airway in Fluent


#include "udf.h"

real density7 = 1.225;
real comp_7 = 8.99e-8;	/* define necessary compliances at outlets */
real total_flow_mass_outlet7;
int i;
real dmdt7;
real flow7[2] = {0.0, 0.0};



DEFINE_PROFILE(pressure_BC7, thread, position)
{
	
	face_t f;

	Thread *t;
	int n7 = N_TIME;
	real dt7;

	real time = CURRENT_TIME;
	real dtime = CURRENT_TIMESTEP;
	real mass_flow_rate_outlet7 = 0;

	real flow_acce7; // = RP_Get_Real("dmdt7");
	
	begin_f_loop(f, thread)
	{
		mass_flow_rate_outlet7 += F_FLUX(f, thread);

		total_flow_mass_outlet7 += F_FLUX(f, thread)*dtime;
		
	}
	end_f_loop(f, thread)

	Message("mass flow rate at outlet7: %g\n", mass_flow_rate_outlet7);
//	printf("total mass downstream of outlet7: %g\n", total_flow_mass_outlet7);



	begin_f_loop(f, thread)
	{
		flow7[1] += F_FLUX(f, thread);	
	}
	end_f_loop(f, thread)	

	dmdt7 = (flow7[1] - flow7[0])/dtime;

	Message("Derivative of mass flow rate7: %g\n", dmdt7);
	Message("flow7[1] value is: %g\n", flow7[1]);
	Message("flow7[0] value is: %g\n", flow7[0]);


	begin_f_loop(f, thread)
	{
		
		F_PROFILE(f, thread, position) = total_flow_mass_outlet7/density7*9016422;// + 1079733*mass_flow_rate_outlet7/density7 + 9017*dmdt7/density7;
	}
	end_f_loop(f, thread)

	mass_flow_rate_outlet7 = 0;
	flow7[0] = flow7[1];
	flow7[1] = 0;
}


